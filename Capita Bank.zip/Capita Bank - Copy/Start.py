import re
from stringprep import b3_exceptions
from tkinter import *
from tkinter import messagebox as ms
from PIL import ImageTk, Image
import sqlite3 as s
d=s.connect("bank.dB")
k=d.cursor()
is_password_visible = False
def Start():
    global w1
    w1=Tk()
    w1.title("Starting Page")
    w1.geometry("700x600")
    w1.config(bg="#e6f0ff")
    w1.attributes('-fullscreen',True)
    w1.bind("<Escape>", lambda e: w1.attributes("-fullscreen", False))
    img=Image.open("logo2 - Copy.png")
    img = img.resize((400, 400))
    photo=ImageTk.PhotoImage(img)
    ii=Label(w1,image=photo, bg=w1['bg'],bd=0)
    ii.pack()
    text="Welcome to Capita Bank😁"
    L1=Label(w1,text="", font=("times new roman", 50, 'bold', 'underline'),bg='#e6f0ff', fg='#003366')
    def type_text(i=0):
        try:
            if i < len(text):
             L1.config(text=L1["text"]+text[i])
             w1.after(50,type_text,i+1)
        except:
            pass
    type_text()
    L1.place(x=380,y=300)
    L2=Label(w1,text='Your Capital, Our Priority', font=("arial",30),bg='#e6f0ff', fg='gold')
    L2.place(x=550,y=400)
    img1=Image.open("starB.png")
    img1=img1.resize((160,140))
    photo1=ImageTk.PhotoImage(img1)
    E1=Button(w1,image=photo1,command=Account_Type,bg=w1['bg'],bd=0,activebackground=w1['bg'])
    E1.place(x=700,y=450)
    photo2=ImageTk.PhotoImage(Image.open("hello.png").resize((160,160)))
    hello=Label(w1,image=photo2,bg=w1['bg'],bd=0)
    hello.place(x=1180,y=230)
    photo3 = ImageTk.PhotoImage(Image.open("hello - Copy.png").resize((160, 160)))
    hello1 = Label(w1, image=photo3,bg=w1['bg'], bd=0)
    hello1.place(x=220, y=230)
    w1.mainloop()
def Account_Type():
    global w2
    try:
        w1.destroy()
    except:
        pass
    try:
        w3.destroy()
    except:
        pass
    try:
        w5.destroy()
    except:
        pass
    try:
        w6.destroy()
    except:
        pass
    try:
        w7.destroy()
    except:
        pass
    w2=Tk()
    w2.attributes("-fullscreen", True)
    w2.bind_all("<Escape>", lambda e: w2.attributes("-fullscreen", False))
    w2.title("Account Type")
    w2.geometry("700x600")
    w2.config(bg='#e6f0ff')
    L1 = Label(w2, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    L1.place(x=700, y=300)
    l2=Label(w2,text="Choose Your Account Type:", font=("times new roman",20,), bg='#e6f0ff', fg='gold')
    l2.place(x=650,y=350)
    img1=Image.open("register.png")
    img1=img1.resize((150,100))
    photo1=ImageTk.PhotoImage(img1)
    b1=Button(w2,image=photo1,command=New_user,bg=w2['bg'],bd=0,activebackground=w2['bg'])
    b1.place(x=350,y=410)
    img2=Image.open("login.png")
    img2=img2.resize((150,120))
    photo2=ImageTk.PhotoImage(img2)
    b2 = Button(w2, image=photo2,command=login,bg=w2['bg'],bd=0,activebackground=w2['bg'])
    b2.place(x=600, y=400)
    img3=Image.open("EMPLOYEE.png")
    img3=img3.resize((150,50))
    photo3=ImageTk.PhotoImage(img3)
    b3 = Button(w2, image=photo3,command=Employee,bg=w2['bg'],bd=0,activebackground=w2['bg'])
    b3.place(x=850, y=435)
    img4=Image.open("ADMIN.png")
    img4=img4.resize((150,50))
    photo4=ImageTk.PhotoImage(img4)
    b4 = Button(w2, image=photo4,command=Admin,bg=w2['bg'],bd=0)
    b4.place(x=1100, y=431)
    w2.mainloop()
def New_user():
    global w3
    try:
        w2.destroy()
    except:
        pass
    w3=Tk()
    w3.title("New User Registration")
    w3.geometry("700x600")
    w3.config(bg='#e6f0ff')
    w3.attributes("-fullscreen",True)
    w3.bind("<Escape>", lambda e: w3.attributes("-fullscreen",False))
    L1 = Label(w3, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    L1.pack()
    l8=Label(w3,text="New User Registration", font=("times new roman", 20, 'bold', 'underline'), bg='#e6f0ff', fg='gold')
    l8.pack()
    l2=Label(w3,text="First Name ", font=("arial", 20, 'bold'), bg='#e6f0ff', fg='Black')
    l2.place(x=450,y=100)
    e1=Entry(w3,font=('arial', 20),)
    e1.place(x=650,y=100)
    l3 = Label(w3, text="Last Name ", font=("arial", 20, 'bold'), bg='#e6f0ff',fg='Black')
    l3.place(x=450,y=200)
    e2 = Entry(w3, font=('arial', 20), )
    e2.place(x=650, y=200)
    l4 = Label(w3, text="Mobile No. ", font=("arial", 20, 'bold'), bg='#e6f0ff',fg='Black')
    l4.place(x=450,y=300)
    e3 = Entry(w3, font=('arial', 20), )
    e3.place(x=650, y=300)
    l5 = Label(w3, text="Email Add. ", font=("arial", 20, 'bold'), bg='#e6f0ff',fg='Black')
    l5.place(x=450, y=400)
    e4 = Entry(w3, font=('arial', 20), )
    e4.place(x=650, y=400)
    l6 = Label(w3, text="Date Of Birth ", font=("arial", 20, 'bold'), bg='#e6f0ff',fg='Black')
    l6.place(x=450,y=500)
    e5 = Entry(w3, font=('arial', 20), )
    e5.place(x=650, y=500)
    l7=Label(w3,text="Password",font=("arial", 20, 'bold'), bg='#e6f0ff',fg='Black')
    l7.place(x=450,y=600)
    e6 = Entry(w3, font=('arial', 20),show='*' )
    e6.place(x=650, y=600)
    try:
        k.execute("CREATE TABLE User_Data(First_Name VARCHAR(20), Last_Name VARCHAR(20), Mob_No INT, Email_ID VARCHAR(30), DOB VARCHAR(10), Password INT)")
    except:
        pass
    def validation():
        FN = e1.get()
        LN=e2.get()
        Mob=e3.get()
        EM=e4.get()
        DB=e5.get()
        Pass=e6.get()
        if FN=='':
            ms.showerror('Alert',"First Name Cannot be Empty")
        elif LN=='':
            ms.showerror('Alert',"Last Name Cannot Be Empty")
        elif Mob=='':
            ms.showerror('Alert',"Mobile Number Cannot Be empty")
        elif not re.search(r'^\w+@\w+\.[a-z]{2,3}$',e4.get()):
            ms.showerror('Alert', "Email cannot be empty")
        elif not re.search(r'^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(19\d\d|200[0-4])$',DB) or DB=='':
            ms.showerror('Alert',"Date Of Birth Caannot be empty or invalid")
        elif Pass=='':
            ms.showerror('Alert',"Password Cannot be Empty")
        else:
            k.execute("INSERT INTO User_Data (First_Name, Last_Name, Mob_No, Email_ID, DOB, Password)VALUES(?, ?, ?, ?, ?, ?)",(e1.get(),e2.get(),int(e3.get()),e4.get(),e5.get(),int(e6.get())))
            d.commit()
            ms.showinfo("Success", 'Registration Successful')
            login()
    img1=Image.open("submit-button-png-18021.png")
    img1=img1.resize((120,50))
    photo1=ImageTk.PhotoImage(img1)
    b1 = Button(w3, image=photo1, command=validation,bg=w3['bg'],bd=0)
    b1.place(x=580, y=700)
    img2=Image.open("back-button-png.svg.hi.png")
    img2=img2.resize((120,50))
    photo2=ImageTk.PhotoImage(img2)
    b2=Button(w3,image=photo2,command=Account_Type,bg=w3['bg'],bd=0)
    b2.place(x=780,y=700)
    w3.mainloop()
def success():
    global w4
    try:
        w3.destroy()
    except:
        pass
    w4=Tk()
    w4.title("success")
    w4.geometry("700x600")
    w4.config(bg="#e6f0ff")
    w4.attributes("-fullscreen",True)
    w4.bind("<Escape>", lambda e: w4.attributes("-fullscreen", False))
    L1 = Label(w4, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    L1.pack()
    L2=Label(w4,text="Your Account is successfully created \n You can now login with your email and password",font=("times new roman", 30, 'bold',), bg='#e6f0ff', fg='slategray1')
    L2.pack(expand=True)
    B1=Button(w4,text="Login Page", command=login,width=10, font=('arial',15),bg='gold', fg='black', activebackground='black',activeforeground='gold')
    B1.pack(expand=True)
    w4.mainloop()
def login():
    global w5
    try:
        w4.destroy()
    except:
        pass
    try:
        w2.destroy()
    except:
        pass
    try:
        w3.destroy()
    except:
        pass

    w5 = Tk()
    w5.title("Login")
    w5.geometry("700x600")
    w5.config(bg='#e6f0ff')
    w5.attributes('-fullscreen',True)
    w5.bind("<Escape>", lambda e: w5.attributes("-fullscreen",False))
    L1 = Label(w5, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    L1.pack()
    L2 = Label(w5, text="Login Existing User", font=("times new roman", 20, 'bold', 'underline'), bg='#e6f0ff',fg='gold')
    L2.pack()
    L3=Label(w5,text="Email", font=("arial", 20, 'bold'), bg='#e6f0ff', fg='Black')
    L3.place(x=450,y=300)
    L4=Label(w5,text="Password", font=("arial", 20, 'bold'), bg='#e6f0ff', fg='Black')
    L4.place(x=450,y=350)
    e1=Entry(w5,font=('arial', 20))
    e1.place(x=700,y=300)
    e2=Entry(w5,font=('arial', 20),show='*')
    e2.place(x=700,y=350)
    open_img=ImageTk.PhotoImage(Image.open("show.png").resize((50,50)))
    close_img=ImageTk.PhotoImage(Image.open("hide.png").resize((50,50)))
    def toggle_password():
        global is_password_visible
        if is_password_visible:
            e2.config(show='*')
            pass_hid_show.config(image=open_img)
            is_password_visible=False
        else:
            e2.config(show="")
            pass_hid_show.config(image=close_img)
            is_password_visible=True
    pass_hid_show=Button(w5,image=open_img,command=toggle_password,bd=0,bg=w5['bg'],activebackground=w5['bg'])
    pass_hid_show.image = open_img
    pass_hid_show.place(x=1010,y=345)
    def Validation():
        EM=e1.get()
        Pass=e2.get()
        k.execute("SELECT First_Name,Last_Name,ID FROM User_Data WHERE Email_ID=? AND Password=?", (EM, Pass))
        N = k.fetchone()
        if N:
            full_name=N[0]+' ' + N[1]
            account=N[2]
            ms.showinfo('Success', f'You Have Successfully Log in, {full_name}')
            w5.destroy()
            user_page(full_name,account)
        else:
            ms.showerror('Alert', "Invalid Id or Password")
    img2=Image.open("submit-button-png-18021.png")
    img2=img2.resize((100,50))
    photo2=ImageTk.PhotoImage(img2)
    b1=Button(w5,image=photo2,command=Validation,bg=w5['bg'],bd=0)
    b1.place(x=610,y=400)
    img3=Image.open("back-button-png.svg.hi.png")
    img3=img3.resize((120,50))
    photo3=ImageTk.PhotoImage(img3)
    b2 = Button(w5, image=photo3,command=Account_Type,bg=w5['bg'], bd=0)
    b2.place(x=830, y=400)
    w5.mainloop()
def Employee():
    global w6
    try:
        w2.destroy()
    except:
        pass
    w6 = Tk()
    w6.title("Login")
    w6.geometry("700x600")
    w6.config(bg='#e6f0ff')
    w6.attributes("-fullscreen",True)
    w6.bind("<Escape>",lambda e: w6.attributes('-fullscreen', False))
    L1 = Label(w6, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    L1.pack()
    L2 = Label(w6, text="Employee Login", font=("times new roman", 20, 'bold', 'underline'), bg='#e6f0ff',
               fg='gold')
    L2.pack()
    L3 = Label(w6, text="Employee ID", font=("arial", 20, 'bold'), bg='#e6f0ff', fg='Black')
    L3.place(x=450, y=300)
    L4 = Label(w6, text="Password", font=("arial", 20, 'bold'), bg='#e6f0ff', fg='Black')
    L4.place(x=450, y=350)
    e1 = Entry(w6, font=('arial', 20))
    e1.place(x=700, y=300)
    e2 = Entry(w6, font=('arial', 20), show='*')
    e2.place(x=700, y=350)
    open_img = ImageTk.PhotoImage(Image.open("show.png").resize((50, 50)))
    close_img = ImageTk.PhotoImage(Image.open("hide.png").resize((50, 50)))

    def toggle_password():
        global is_password_visible
        if is_password_visible:
            e2.config(show='*')
            pass_hid_show.config(image=open_img)
            is_password_visible = False
        else:
            e2.config(show="")
            pass_hid_show.config(image=close_img)
            is_password_visible = True

    pass_hid_show = Button(w6, image=open_img, command=toggle_password, bd=0, bg=w6['bg'], activebackground=w6['bg'])
    pass_hid_show.image = open_img
    pass_hid_show.place(x=1010, y=345)
    def validat():
        try:
            ID = int(e1.get())
            Pass = int(e2.get())
        except:
            ms.showerror("Invalid Input","ID and Password should be in Numeric")
        else:
            k.execute("select Name from employee where ID=? and Password=?", (ID, Pass))
            fat = k.fetchone()
            if fat:
                Name=fat[0]
                ms.showinfo("Login Successfull", f"Welcome {Name}")
                employee_page(ID,Name)
                try:
                    w6.destroy()
                except:
                    pass
            else:
                ms.showerror("Error", "ID or password is incorrect")
    global img2
    img2 = Image.open("submit-button-png-18021.png")
    img2 = img2.resize((100, 50))
    photo2 = ImageTk.PhotoImage(img2)
    b1 = Button(w6,image=photo2,command=validat,bg=w6['bg'],bd=0)
    b1.place(x=600,y=400)
    img3 = Image.open("back-button-png.svg.hi.png")
    img3 = img3.resize((120, 50))
    photo3 = ImageTk.PhotoImage(img3)
    b2 = Button(w6,image=photo3, command=Account_Type, bg=w6["bg"],bd=0)
    b2.place(x=780, y=400)
    w6.mainloop()
def Admin():
    global w7
    try:
        w2.destroy()
    except:
        pass
    w7 = Tk()
    w7.title("Login")
    w7.geometry("700x600")
    w7.attributes("-fullscreen",True)
    w7.bind("<Escape>", lambda e: w7.attributes('-fullscreen', False))
    w7.config(bg='#e6f0ff')
    L1 = Label(w7, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    L1.pack()
    L2 = Label(w7, text="Admin Login", font=("times new roman", 20, 'bold', 'underline'), bg='#e6f0ff',
               fg='gold')
    L2.pack()
    L3 = Label(w7, text="Admin ID", font=("arial", 20, 'bold'), bg='#e6f0ff', fg='Black')
    L3.place(x=450, y=300)
    L4 = Label(w7, text="Password", font=("arial", 20, 'bold'), bg='#e6f0ff', fg='Black')
    L4.place(x=450, y=350)
    e1 = Entry(w7, font=('arial', 20))
    e1.place(x=700, y=300)
    e2 = Entry(w7, font=('arial', 20), show='*')
    e2.place(x=700, y=350)
    open_img = ImageTk.PhotoImage(Image.open("show.png").resize((50, 50)))
    close_img = ImageTk.PhotoImage(Image.open("hide.png").resize((50, 50)))

    def toggle_password():
        global is_password_visible
        if is_password_visible:
            e2.config(show='*')
            pass_hid_show.config(image=open_img)
            is_password_visible = False
        else:
            e2.config(show="")
            pass_hid_show.config(image=close_img)
            is_password_visible = True

    pass_hid_show = Button(w7, image=open_img, command=toggle_password, bd=0, bg=w7['bg'], activebackground=w7['bg'])
    pass_hid_show.image = open_img
    pass_hid_show.place(x=1010, y=345)
    def valid():
        id=e1.get()
        passw=e2.get()
        if id=='':
            ms.showerror("Error","ID cannot be empty")
        elif passw == '':
            ms.showerror("Error","Password cannot be empty")
        else:
            id1=int(id)
            passw1=int(passw)
            k.execute("select ID,FULL_name,Password from Admin where ID=? and Password=?",(id1,passw1))
            er=k.fetchone()
            if not er:
                ms.showerror("Invalid","Invalid ID or password")
            else:
                admin_ID=er[0]
                admin_name=er[1]
                ms.showinfo("Success",f"You have Successfully logged in\nMr. {admin_name}")
                adminwork(admin_ID,admin_name)
                w7.destroy()
    img2 = Image.open("submit-button-png-18021.png")
    img2 = img2.resize((100, 50))
    photo2 = ImageTk.PhotoImage(img2)
    b1 = Button(w7,image=photo2,command=valid, bg=w7['bg'],bd=0)
    b1.place(x=600,y=400)
    img3 = Image.open("back-button-png.svg.hi.png")
    img3 = img3.resize((120, 50))
    photo3 = ImageTk.PhotoImage(img3)
    b2 = Button(w7, image=photo3, command=Account_Type,bg=w7['bg'],bd=0)
    b2.place(x=780, y=400)
    w7.mainloop()
def user_page(name,ID):
    global w8
    try:
        w5.destroy()
    except:
        pass
    try:
        w9.destroy()
    except:
        pass
    w8=Tk()
    w8.title("Dashboard")
    w8.geometry("700x600")
    w8.config(bg="#e6f0ff")
    w8.attributes("-fullscreen",True)
    w8.bind_all("<Escape>", lambda e: w8.attributes("-fullscreen",False))
    l1=Label(w8,text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4=Label(w8,text="Dashboard",font=("times new roman",30,'bold','underline'), bg='#e6f0ff', fg="#4169E1")
    l4.pack()
    l2 = Label(w8, text=f"Welcome {name} (Account Number: {ID})", font=("times new roman", 20, 'bold'), bg='#e6f0ff', fg='Black')
    l2.pack()
    acc=ID
    colors = ["navy", "darkgreen", "crimson", "indigo", "teal", "maroon", "darkorange", "purple", "royalblue", "firebrick"]
    i=0
    def change_color():
        nonlocal i
        try:
            l1.config(fg=colors[i])
            i=(i+1)%len(colors)
            w8.after(500,change_color)
        except:
            pass
    change_color()
    try:
        k.execute("SELECT Balance,Acc_Type FROM User_Data WHERE ID=?", (acc,))
        N=k.fetchone()
        E1=N[0]
        E2=N[1]
        l5=Label(w8,text="Current balance:",font=("arial",40), bg="#e6f0ff")
        l5.pack()
        l6=Label(w8,text=f"₹{E1}",font=("arial",40,'bold'), bg="#e6f0ff")
        l6.pack()
        l7=Label(w8,text=f"{E2}",font=("arial",20),bg="#e6f0ff")
        l7.pack()
        def logout():
            try:
                ans=ms.askyesno("Alert",'Do You want To Logout!')
                if ans:
                    ms.showinfo("Logout Successfully",f"Thank You {name} for trusting us \nWe will wait for you")
                    w8.destroy()
                else:
                    ms.showinfo("Logout cancel",'Logout is cancelled')
            except:
                pass
        img=Image.open("logout.png")
        img=img.resize((120,110))
        photo1=ImageTk.PhotoImage(img)
        b1=Button(w8,image=photo1,command=logout,bg=w8['bg'],bd=0, activebackground=w8['bg'])
        b1.place(x=915,y=550)
        img1=Image.open("profile.png")
        img1=img1.resize((120,120))
        photo2=ImageTk.PhotoImage(img1)
        b2=Button(w8,image=photo2,command=lambda :profile(name,ID),bg=w8['bg'],bd=0)
        b2.place(x=515,y=550)
    except:
        pass
    img2=Image.open("Money transfer.png")
    img2=img2.resize((120,110))
    photo3=ImageTk.PhotoImage(img2)
    b3=Button(w8,image=photo3,command=lambda: money_transfer(name,ID),bg=w8['bg'],bd=0,activebackground=w8['bg'])
    b3.place(x=320,y=350)
    img3=Image.open("arrow.png")
    img3=img3.resize((120,110))
    photo4=ImageTk.PhotoImage(img3)
    b4=Button(w8,image=photo4,command= lambda :deposit(ID),bg=w8['bg'],bd=0,activebackground=w8['bg'])
    b4.place(x=710,y=350)
    img4=Image.open("transaction-history.png")
    img4=img4.resize((120,110))
    photo5=ImageTk.PhotoImage(img4)
    b5=Button(w8,image=photo5,command=lambda :transaction_history(ID),bg=w8['bg'], bd=0, activebackground=w8['bg'])
    b5.place(x=1120,y=350)
    logo = Label(w8, text="Money Transfer                               Deposit                                  Transactions", font=("arial", 20), bg=w8['bg'])
    logo.place (x=290,y=470)
    logo1=Label(w8,text="   Profile                                         Logout",font=("arial", 20), bg=w8['bg'] )
    logo1.place(x=510,y=685)
    def click(event):
        print("Mouse clicked at: (%s, %s)" % (event.x, event.y))
    w8.bind('<Button-1>', click)
    w8.mainloop()
def profile(Name,id):
    global w9
    try:
        w8.destroy()
    except:
        pass
    w9 = Tk()
    w9.title("Profile")
    w9.geometry("700x600")
    w9.config(bg="#e6f0ff")
    w9.attributes("-fullscreen", True)
    w9.bind_all("<Escape>", lambda e: w9.attributes("-fullscreen", False))
    img1 = Image.open("backgroun.png")
    img1 = img1.resize((500, 900))
    photo1 = ImageTk.PhotoImage(img1)
    l2 = Label(w9, image=photo1, bg=w9['bg'], bd=0)
    l2.place(x=50, y=150)
    l1 = Label(w9, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l3 = Label(w9, text="Profile", font=("times new roman", 40, 'bold', 'underline'), bg='#e6f0ff', fg="#4169E1")
    l3.pack()
    l4=Label(w9,text=f"{Name}",font=("times new roman", 50,'bold'),bg=w9['bg'],fg='Black')
    l4.place(x=60,y=40)
    l5 = Label(w9, text=f"Account No. :{id}", font=("times new roman", 20, 'bold'), bg=w9['bg'], fg='Black')
    l5.place(x=120, y=115)
    global wet
    img01=Image.open("back-button-png.svg.hi.png")
    img01=img01.resize((150,110))
    wet=ImageTk.PhotoImage(img01)
    back1=Button(w9,image=wet,command=lambda :user_page(Name,id),bg=w9['bg'],bd=0,activebackground=w9['bg'])
    back1.place(x=1350,y=750)
    def basic():
        global l6
        try:
            pa.destroy()
        except:
            pass
        try:
            fa.destroy()
        except:
            pass
        try:
            la.destroy()
        except:
            pass
        try:
            F1.destroy()
        except:
            pass
        try:
            em.destroy()
        except:
            pass
        try:
            F2.destroy()
        except:
            pass
        try:
            B1.destroy()
        except:
            pass
        try:
            oz.destroy()
        except:
            pass
        try:
            wh.destroy()
        except:
            pass
        try:
            fn.destroy()
        except:
            pass
        try:
            Na.destroy()
        except:
            pass
        try:
            la1.destroy()
        except:
            pass
        try:
            Ne.destroy()
        except:
            pass
        try:
            B3.destroy()
        except:
            pass
        try:
            N1.destroy()
        except:
            pass
        try:
            ra.destroy()
        except:
            pass
        try:
            q1.destroy()
        except:
            pass
        try:
            E4.destroy()
        except:
            pass

        k.execute("select * from User_Data where Id=?",(id,))
        N=k.fetchone()
        full=N[0]+" "+N[1]
        if N:
            l6=Label(w9,text=f'Name: {full}\nAccount Number: {N[6]}\nMobile Number: {N[2]}\nEmail ID: {N[3]}\nDate Of Birth: {N[4]}\nBalance: {N[7]}\nAccount Type: {N[8]}',font=("arial",45),justify='left',bg=w9['bg'],bd=0)
            l6.place(x=720,y=250)
        else:
            l6=Label(w9,text="No data found",font=("arial",20),bg=w9['bg'])
            l6.place(x=420, y=250)
    b1=Button(w9,text="Basic Details",command=basic, font=("arial",20), bg="#ebf3ff", bd=0,fg='black',activebackground="#ebf3ff")
    b1.place(x=160,y=170)
    def update():
        global pa,fa,la,F1,em,F2,B1
        global submitt_img, submitt1_img, submitt2_img, submitt3_img
        try:
            l6.destroy()
        except:
            pass
        k.execute("select First_Name,Last_Name, Email_ID from User_Data where id=?",(id,))
        N=k.fetchone()
        pa=Label(w9,text="Enter First Name:",font=("arial",30),bg=w9['bg'],bd=0)
        pa.place(x=600, y=250)
        fa=Entry(w9,font=("arial",30))#E1
        fa.place(x=950,y=250)
        # global fa
        la = Label(w9, text="Enter Last Name:", font=("arial", 30), bg=w9['bg'], bd=0)
        la.place(x=600, y=300)
        # global la
        F1 = Entry(w9, font=("arial", 30))#E2
        F1.place(x=950, y=300)
        # global F1
        em = Label(w9, text="Enter Email:", font=("arial", 30), bg=w9['bg'], bd=0)
        em.place(x=600, y=350)
        # global em
        F2 = Entry(w9, font=("arial", 30))#E3
        F2.place(x=950, y=350)
        # global F2
        def sub():
            global oz,wh,E4
            FN = fa.get()
            LN = F1.get()
            EM = F2.get()
            try:
                pa.destroy()
            except:
                pass
            try:
                fa.destroy()
            except:
                pass
            try:
                la.destroy()
            except:
                pass
            try:
                F1.destroy()
            except:
                pass
            try:
                em.destroy()
            except:
                pass
            try:
                F2.destroy()
            except:
                pass
            try:
                B1.destroy()
            except:
                pass
            if FN=='':
                ms.showerror("alert","First Name Cannot be Empty")
            elif LN == '':
                ms.showerror('Alert','Last Name Cannot be empty')
            elif EM=='':
                ms.showerror("Alert","Email Address Cannot be empty")
            else:
                if FN == N[0] and LN == N[1] and EM == N[2]:
                    ms.showinfo('Success', 'You Can Update Your Details')
                    wh = Label(w9, text="What do you want to update\n1.Name\n2.Mobile No.\n3.Email Id\n4.Date Of Birth\n5. Password",font=("arial",25),justify='left',bg=w9['bg'],bd=0)
                    wh.place(x=720,y=250)
                    E4=Entry(w9,font=("arial",40))
                    E4.place(x=720,y=530)
                    def choose():
                        global fn,Na,la1,Ne,B3
                        Choice=E4.get()
                        if Choice=='Name' or Choice=="1" or Choice=='name':
                            try:
                                wh.destroy()
                            except:
                                pass
                            try:
                                E4.destroy()
                            except:
                                pass
                            try:
                                oz.destroy()
                            except:
                                pass
                            fn=Label(w9,text="Enter First Name:",font=("arial",30),bg=w9['bg'],bd=0)
                            fn.place(x=600, y=250)
                            Na = Entry(w9, font=("arial", 30))
                            Na.place(x=950, y=250)
                            la1 = Label(w9, text="Enter Last Name:", font=("arial", 30), bg=w9['bg'], bd=0)
                            la1.place(x=600, y=300)
                            Ne = Entry(w9, font=("arial", 30))
                            Ne.place(x=950, y=300)
                            def naming():
                                global N1,ra,q1
                                A=Na.get()
                                B=Ne.get()
                                k.execute("update user_Data set First_Name=?,Last_Name=? where ID=?",(A,B,id))
                                d.commit()
                                if k.rowcount>0:
                                    ms.showinfo('Success',"Data is Updated")
                                    try:
                                        fn.destroy()
                                    except:
                                        pass
                                    try:
                                        Na.destroy()
                                    except:
                                        pass
                                    try:
                                        la1.destroy()
                                    except:
                                        pass
                                    try:
                                        Ne.destroy()
                                    except:
                                        pass
                                else:
                                    ms.showerror('Error',"Data is not updated")
                            global submitt_img
                            img2 = Image.open("submit-button-png-18021.png").resize((100, 50))
                            submitt_img = ImageTk.PhotoImage(img2)
                            N1 = Button(w9, image=submitt_img, command=naming, bg=w9['bg'], bd=0,activebackground=w9['bg'])
                            N1.place(x=600, y=400)
                        elif Choice == "Mobile NO." or Choice == "2":
                            try:
                                wh.destroy()
                            except:
                                pass
                            try:
                                E4.destroy()
                            except:
                                pass
                            try:
                                oz.destroy()
                            except:
                                pass
                            ra = Label(w9, text="Enter New Mobile No.:", font=("arial", 30), bg=w9['bg'], bd=0)
                            ra.place(x=600, y=250)
                            q1 = Entry(w9, font=("arial", 30))
                            q1.place(x=600, y=300)
                            def mob():
                                A=int(q1.get())
                                ms.askyesno('Remainder',f"Do you confirm {A}")
                                if A is not None and len(str(A))==10:
                                    k.execute("update user_Data set Mob_No=? where ID=?",(A,id))
                                    d.commit()
                                    if k.rowcount>0:
                                        ms.showinfo('Success',"Data is Updated")
                                        try:
                                            ra.destroy()
                                        except:
                                            pass
                                        try:
                                            q1.destroy()
                                        except:
                                            pass
                                    else:
                                        ms.showerror('Error',"Data is not updated")
                                else:
                                    ms.showerror("Error",'Inavlid or less digit')
                            global submitt1_img
                            img3 = Image.open("submit-button-png-18021.png").resize((100, 50))
                            submitt1_img = ImageTk.PhotoImage(img3)
                            B3 = Button(w9, image=submitt1_img, command=mob, bg=w9['bg'], bd=0,activebackground=w9['bg'])
                            B3.place(x=800, y=400)
                        elif Choice=="Email ID" or Choice == "3" :
                            try:
                                wh.destroy()
                            except:
                                pass
                            try:
                                E4.destroy()
                            except:
                                pass
                            try:
                                oz.destroy()
                            except:
                                pass
                            ei1=Label(w9, text="Enter New Email:", font=("arial", 30), bg=w9['bg'], bd=0)
                            ei1.place(x=600, y=250)
                            ei2 = Entry(w9, font=("arial", 30))
                            ei2.place(x=600, y=300)
                            def email():
                                ei3=ei2.get()
                                if not re.search(r'^\w+@\w+\.[a-z]{2,3}$', ei2.get()) or ei2.get() == '':
                                    ms.showerror("Error", 'Format not match or empty field')
                                    return
                                if ms.askyesno('Remainder', f"Do you confirm {ei3}"):
                                    k.execute("update User_Data set Email_ID=? where ID=?",(ei3,id))
                                    d.commit()
                                    if k.rowcount>0:
                                        ms.showinfo("Updated", 'Email has been updated')
                                    else:
                                        ms.showerror('Error','Email is not Updated')
                            global arun_img
                            arun1 = Image.open("submit-button-png-18021.png").resize((100, 50))
                            arun_img = ImageTk.PhotoImage(arun1)
                            aj = Button(w9, image=arun_img, command=email, bg=w9['bg'], bd=0,
                                        activebackground=w9['bg'])
                            aj.place(x=800, y=400)
                        elif Choice=="Date Of Birth" or Choice == "4" :
                            try:
                                wh.destroy()
                            except:
                                pass
                            try:
                                E4.destroy()
                            except:
                                pass
                            try:
                                oz.destroy()
                            except:
                                pass
                            ej1=Label(w9, text="Enter New Date Of birth:", font=("arial", 30), bg=w9['bg'], bd=0)
                            ej1.place(x=600, y=250)
                            ej2 = Entry(w9, font=("arial", 30))
                            ej2.place(x=600, y=300)
                            def dob():
                                ej3=ej2.get()
                                if not re.match(r'^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(19\d\d|200[0-4])$', ej3):
                                    ms.showerror("Error", 'Format not match or empty field')
                                    return
                                if ms.askyesno('Remainder', f"Do you confirm {ej3}"):
                                    k.execute("update User_Data set DOB=? where ID=?",(ej3,id))
                                    d.commit()
                                    if k.rowcount>0:
                                        ms.showinfo("Updated", 'Date of birth has been updated')
                                        try:
                                            ej1.destroy()
                                        except:
                                            pass
                                        try:
                                            ej2.destroy()
                                        except:
                                            pass
                                    else:
                                        ms.showerror('Error','DOB is not Updated')
                            global arun2_img
                            arun2 = Image.open("submit-button-png-18021.png").resize((100, 50))
                            arun2_img = ImageTk.PhotoImage(arun2)
                            aj1 = Button(w9, image=arun2_img, command=dob, bg=w9['bg'], bd=0,
                                        activebackground=w9['bg'])
                            aj1.place(x=800, y=400)
                        elif Choice=="Password" or Choice=='5':
                            try:
                                wh.destroy()
                            except:
                                pass
                            try:
                                E4.destroy()
                            except:
                                pass
                            try:
                                oz.destroy()
                            except:
                                pass
                            eq1=Label(w9, text="Enter New Password:", font=("arial", 30), bg=w9['bg'], bd=0)
                            eq1.place(x=600, y=250)
                            eq2 = Entry(w9, font=("arial", 30))
                            eq2.place(x=600, y=300)
                            def passw():
                                eq3=int(eq2.get())
                                k.execute("select Password from User_Data where ID=?",(id,))
                                N=k.fetchone()
                                if eq3==N[0]:
                                    ms.showerror("Error", 'This is old password')
                                    return
                                if ms.askyesno('Remainder', f"Do you confirm {eq3}"):
                                    k.execute("update User_Data set Password=? where ID=?",(eq3,id))
                                    d.commit()
                                    if k.rowcount>0:
                                        ms.showinfo("Updated", 'Password has been updated')
                                        try:
                                            eq1.destroy()
                                        except:
                                            pass
                                        try:
                                            eq2.destroy()
                                        except:
                                            pass
                                    else:
                                        ms.showerror('Error','DOB is not Updated')
                            global arun3_img
                            arun3 = Image.open("submit-button-png-18021.png").resize((100, 50))
                            arun3_img = ImageTk.PhotoImage(arun3)
                            aj1 = Button(w9, image=arun3_img, command=passw, bg=w9['bg'], bd=0,
                                        activebackground=w9['bg'])
                            aj1.place(x=800, y=400)
                    global submitt2_img
                    img4 = Image.open("submit-button-png-18021.png").resize((100, 50))
                    submitt2_img = ImageTk.PhotoImage(img4)
                    oz = Button(w9, image=submitt2_img, command=choose, bg=w9['bg'], bd=0, activebackground=w9['bg'])
                    oz.place(x=900, y=600)

                else:
                    ms.showerror("ALert", "Wrong Detail")
        global submitt3_img
        img5 = Image.open("submit-button-png-18021.png").resize((100, 50))
        submitt3_img = ImageTk.PhotoImage(img5)
        B1=Button(w9,image=submitt3_img,command=sub,bg=w9['bg'],bd=0,activebackground=w9['bg'])
        B1.place(x=800,y=700)
    b2 = Button(w9, text="Update Profile", command=update, font=("arial", 20), bg="#ebf3ff", bd=0, fg='black',activebackground="#ebf3ff")
    b2.place(x=155, y=240)
    w9.mainloop()
def money_transfer(Names,IDS):
    w10=Toplevel()
    w10.title("Money Transfer")
    w10.geometry("800x600")
    w10.config(bg="#e6f0ff")
    w10.attributes("-topmost",True)
    w10.resizable(False,False)
    l1 = Label(w10, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l2 = Label(w10, text="Money Transfer", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg="#4169E1")
    l2.pack()
    l4 = Label(w10, text=f"{Names}", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
    l4.pack()
    l3=Label(w10,text=f"User Account           {IDS} \nSender Account\nAmount",font=('arial',20),bg=w10['bg'], justify="left")
    l3.place(x=100,y=160)
    e1=Entry(w10,font=("arial",20))
    e1.place(x=350,y=192)
    e2 = Entry(w10, font=("arial", 20))
    e2.place(x=350, y=230)
    def trans():
        try:
            k.execute("select Balance from User_Data where ID=?", (IDS,))
            Q = list(k.fetchone())
            ab1 = int(e1.get())
            amou = int(e2.get())
            print(IDS,amou,ab1)
            # try:
            k.execute("select ID,Balance from User_Data where ID=?",(ab1,))
            tu=list(k.fetchone())
            if amou <= Q[0]:
                new_amo=tu[1]+amou
                k.execute("update User_Data set Balance=? where ID=?",(new_amo,tu[0]))
                d.commit()
                tg = Q[0] - amou
                k.execute("update User_Data set Balance=? where ID=?", (tg, IDS))
                d.commit()
                if k.rowcount > 0:
                    k.execute("select First_Name, Last_Name from User_Data where ID=?",(ab1,))
                    jj=k.fetchone()
                    full_n=jj[0]+" "+jj[1]
                    k.execute("INSERT INTO Transactions (User_ID, Type, Amount, To_Account,Name) VALUES (?,?, ?, ?,?)",(IDS,'Transfer', amou, ab1,full_n))
                    d.commit()
                    # w10.attributes("-topmost",False)
                    m=ms.askyesno('Transferred',"DO you want to transfer more money",parent=w10)
                    if not m:
                        try:
                            w10.destroy()
                        except:
                            pass
                    else:
                        e1.delete(0, END)
                        e2.delete(0, END)
                else:
                    ms.showerror("Error", "Technical Problem\nTry after sometime",parent=w10)
                    w10.destroy()
            elif ab1==IDS:
                ms.showerror("Error","You cannot send fund to yourself",parent=w10)
            else:
                ms.showerror('Insufficient Balance', "Sorry You don't have Sufficient Balance",parent=w10)
        except Exception as e:
            ms.showerror("Error",str(e),parent=w10)
    img1=Image.open("transfer.png").resize((110,100))
    transfer_img=ImageTk.PhotoImage(img1)
    bll=Button(w10,image=transfer_img,command=trans,bg=w10['bg'],bd=0,activebackground=w10['bg'])
    bll.image=transfer_img
    bll.place(x=350,y=320)
    w10.mainloop()
def transaction_history(idf):
    w11=Toplevel()
    w11.title("Transactions")
    w11.geometry("1200x600")
    w11.config(bg="#e6f0ff")
    w11.attributes("-topmost",True)
    w11.resizable(False,False)
    l1 = Label(w11, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l2 = Label(w11, text="Last Five Transactions", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
    l2.pack()
    l3=Label(w11, text=f"  Account No: \n{idf}", font=("arial", 25, 'bold'), bg='#e6f0ff')
    l3.pack()
    l4=Label(w11,text="T ID        Amount      Acc. No.               Time                    Name",font=("arial", 25, 'bold'), bg='#e6f0ff')
    l4.place(x=80,y=190)
    k.execute("select T_ID,Amount,To_Account,Timestamp,Name from Transactions where User_ID=? and Type=? order by Timestamp desc  limit 5",(idf,"Transfer"))
    data=list(k.fetchall())
    # row=data[0]
    ee=240
    ff=100
    for i in range(len(data)):
        for row in data:
            det = Label(w11, text=f'{row[i]}', font=("arial", 25), bg=w11['bg'], bd=0, justify="left")
            det.place(x=ff, y=ee)
            ee = ee + 50
        if i==3 or i==4:
            ff+=360
        else:
            ff += 150
        ee = 240

    w11.mainloop()
def deposit(IDe):
    w12=Toplevel()
    w12.title("Deposit")
    w12.geometry("800x600")
    w12.resizable(False,False)
    w12.config(bg="#e6f0ff")
    w12.attributes("-topmost",True)
    l1 = Label(w12, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l2 = Label(w12, text="Money Deposit", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
    l2.pack()
    l3 = Label(w12, text=f"  Account No: \n{IDe}", font=("arial", 25, 'bold'), bg='#e6f0ff')
    l3.pack()
    amount=Label(w12,text="Enter Amount:", font=("arial",20),bg=w12['bg'])
    amount.place(x=150,y=200)
    amount1=Entry(w12,font=("arial",20))
    amount1.place(x=350,y=200)
    def startdeposit():
        amount2=int(amount1.get())
        try:
            k.execute("select Balance from User_Data where ID=?",(IDe,))
            d.commit()
            balance=list(k.fetchone())
            if balance:
                balance[0]=balance[0]+amount2
                try:
                    k.execute("update User_Data set Balance=? where ID=?",(balance[0],IDe))
                    d.commit()
                    k.execute("insert into Transactions (User_ID,Type,Amount,To_Account,Name) values (?,?,?,?,?)",(IDe,"Deposit",amount2,"self","self"))
                    d.commit()
                    ms.showinfo("Success",f"Amount is Deposited to account {IDe}",parent=w12)
                    hh=ms.askyesno("","Do you want to deposit more money",parent=w12)
                    if not hh:
                        try:
                            w12.destroy()
                        except:
                            pass
                    else:
                        amount1.delete(0, END)
                except:
                    ms.showerror("Error",'Balance Is not updated',parent=w12)
            else:
                ms.showerror("Error",'Balance is not available',parent=w12)
        except:
            pass
    global photo1
    photo1 = ImageTk.PhotoImage(Image.open("deposit1.png").resize((80, 80)))
    submit=Button(w12,image=photo1,command=startdeposit,bg=w12['bg'],bd=0,activebackground=w12['bg'])
    submit.image=photo1
    submit.place(x=370,y=250)
def employee_page(emp_id,emp_name):
    try:
        w6.destroy()
    except:
        pass
    w13 = Tk()
    w13.title("Dashboard")
    w13.geometry("700x600")
    w13.config(bg="#e6f0ff")
    w13.attributes("-fullscreen", True)
    w13.bind_all("<Escape>", lambda e: w13.attributes("-fullscreen", False))
    l1 = Label(w13, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w13, text="Dashboard", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg="#4169E1")
    l4.pack()
    l2 = Label(w13, text=f"Welcome {emp_name} (Employee ID: {emp_id})", font=("times new roman", 20, 'bold'), bg='#e6f0ff',
               fg='Black')
    l2.pack()
    img1=ImageTk.PhotoImage(Image.open("customer.png").resize((170,170)))
    b1=Button(w13,image=img1,command=add_customer,bg=w13['bg'],bd=0,activebackground=w13['bg'])
    b1.place(x=160,y=280)
    img2=ImageTk.PhotoImage(Image.open("modify_account.png").resize(((160,160))))
    b2=Button(w13,image=img2,command=modify_acc,bg=w13['bg'],bd=0,activebackground=w13['bg'])
    b2.place(x=510,y=300)
    img3=ImageTk.PhotoImage(Image.open("delete_account.png").resize((150,150)))
    b3=Button(w13,image=img3,command=del_acc,bg=w13['bg'],bd=0,activebackground=w13['bg'])
    b3.place(x=890,y=280)
    img4=ImageTk.PhotoImage(Image.open("search_account.png").resize((180,180)))
    b4=Button(w13,image=img4,command=search_acc,bg=w13['bg'],bd=0,activebackground=w13['bg'])
    b4.place(x=1240,y=280)
    b5=Label(w13,text="Add Customer                    Modify Account                        Delete Account                     Search Account", font=("arial",20),bg=w13['bg'])
    b5.place(x=155,y=460)
    img5=ImageTk.PhotoImage(Image.open("all_account.png").resize((180,180)))
    b6=Button(w13,image=img5,command=show_all_accounts,bg=w13['bg'],bd=0,activebackground=w13['bg'])
    b6.place(x=335,y=550)
    img6=ImageTk.PhotoImage(Image.open("loan.png").resize((180,180)))
    b7=Button(w13,image=img6,command=lambda :loan(emp_id),bg=w13['bg'],bd=0,activebackground=w13['bg'])
    b7.place(x=700,y=550)
    def logout():
        a=ms.askyesno("Logout","Do you really wanna logout")
        if a:
            ms.showinfo("Logout Successfull","Thanks you for your time")
            w13.destroy()
        else:
            ms.showinfo("Cancelled","Logout Cancelled")
    img7=ImageTk.PhotoImage(Image.open("logout.png").resize((180,180)))
    b8=Button(w13,image=img7,command=logout,bg=w13['bg'],bd=0,activebackground=w13['bg'])
    b8.place(x=1065,y=550)
    b9=Label(w13,text="View all Account                        Loan Initiate                              Logout",font=("Arial",20),bg=w13['bg'],bd=0)
    b9.place(x=325,y=750)
    w13.mainloop()
def add_customer():
    w14=Toplevel()
    w14.geometry("800x700")
    w14.title("Add New Customer")
    w14.resizable(False,False)
    w14.attributes("-topmost",True)
    w14.config(bg="#e6f0ff")
    l1 = Label(w14, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w14, text="Add New Customers", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg="#4169E1")
    l4.pack()
    l5=Label(w14,text="Customer First Name:",font=("Arial",20),bg=w14['bg'],bd=0,activebackground=w14['bg'])
    l5.place(x=55,y=165)
    l6=Label(w14,text="Customer Last Name:",font=("Arial",20),bg=w14['bg'],bd=0,activebackground=w14['bg'])
    l6.place(x=55,y=218)
    l7=Label(w14,text="Mobile Number:",font=("Arial",20),bg=w14['bg'],bd=0,activebackground=w14['bg'])
    l7.place(x=55,y=271)
    l8=Label(w14,text="Email ID:",font=("Arial",20),bg=w14['bg'],bd=0,activebackground=w14['bg'])
    l8.place(x=55,y=324)
    l9=Label(w14,text="Date Of Birth:",font=("Arial",20),bg=w14['bg'],bd=0,activebackground=w14['bg'])
    l9.place(x=55,y=377)
    l10=Label(w14,text="Password:",font=("Arial",20),bg=w14['bg'],bd=0,activebackground=w14['bg'])
    l10.place(x=55,y=430)
    l12 = Label(w14, text="Password Again:", font=("Arial", 20), bg=w14['bg'], bd=0, activebackground=w14['bg'])
    l12.place(x=55, y=483)
    l11=Label(w14,text="Account Type:",font=("Arial",20),bg=w14['bg'],bd=0,activebackground=w14['bg'])
    l11.place(x=55,y=536)
    FN=Entry(w14,font=("arial",20))
    FN.place(x=430,y=165)
    LN=Entry(w14,font=("arial",20))
    LN.place(x=430,y=218)
    MN=Entry(w14,font=("arial",20))
    MN.place(x=430,y=271)
    EI=Entry(w14,font=("arial",20))
    EI.place(x=430,y=324)
    DOB=Entry(w14,font=("arial",20))
    DOB.place(x=430,y=377)
    P1=Entry(w14,font=("arial",20))
    P1.place(x=430,y=430)
    P2=Entry(w14,font=("arial",20))
    P2.place(x=430,y=483)
    AT = Entry(w14, font=("arial", 20))
    AT.place(x=430, y=536)
    def valid():
        First_name=FN.get()
        Last_name=LN.get()
        Mobile=MN.get()
        Email=EI.get()
        DateofBirth=DOB.get()
        Password1=P1.get()
        Password2=P2.get()
        Acc_Type=AT.get()
        if First_name=='':
            ms.showerror("Error","First Name cannot be empty",parent=w14)
        elif Last_name=='':
            ms.showerror("Error",'Last Name Cannot be Empty',parent=w14)
        elif Mobile =='':
            ms.showerror("Error","Mobile no. cannot be empty or non-numeric",parent=w14)
        elif not re.search(r'^\w+@\w+\.[a-z]{2,3}$',Email) or Email =='':
            ms.showerror("Error",'Inavlid type or empty email',parent=w14)
        elif not re.search(r'^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(19\d\d|200[0-4])$',DateofBirth) or DateofBirth=='':
            ms.showerror("Error",'Date of Birth Cannot be Empty or invalid',parent=w14)
        elif Acc_Type =='':
            ms.showerror("Error","Account Type Cannot Be empty",parent=w14)
        elif Password1==''or Password2=='':
            ms.showerror('Error','Password cannot be empty',parent=w14)
        elif Password1 != Password2:
            ms.showerror("Error","Passwords are not same",parent=w14)
        else:
            Mobile1=int(Mobile)
            Password3=int(Password2)
            k.execute("insert into User_Data (First_Name,Last_Name,Mob_No,Email_ID,DOB,Password,Acc_Type) values (?,?,?,?,?,?,?)",(First_name,Last_name,Mobile1,Email,DateofBirth,Password3,Acc_Type))
            d.commit()
            k.execute("select ID from User_Data where Email_ID=? and Password=?",(Email,Password2))
            g=k.fetchone()
            if g:
                ms.showinfo("Success",f'Account successfully created with account no. {g[0]}',parent=w14)
            else:
                ms.showerror("Error","Account is not created\nPlease try after some time",parent=w14)
    global img
    img=ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110,60)))
    b1=Button(w14,image=img,command= valid,bg=w14['bg'],bd=0,activebackground=w14['bg'])
    b1.image=img
    b1.place(x=299,y=594)
    w14.mainloop()
def modify_acc():
    w15 = Toplevel()
    w15.geometry("800x700")
    w15.title("Modify Customer")
    w15.resizable(False, False)
    w15.attributes("-topmost", True)
    w15.config(bg="#e6f0ff")
    l1 = Label(w15, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w15, text="Modify Account", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
    l4.pack()
    acc_no=Label(w15,text="Enter Account Number:",font=('arial',20),bg=w15['bg'])
    acc_no.place(x=59,y=192)
    acc_n01=Entry(w15,font=('arial',20))
    acc_n01.place(x=382,y=192)
    def find():
        no=acc_n01.get()
        if no=='':
            ms.showerror("Error","Account Number is empty",parent=w15)
        else:
            no1=int(no)
            k.execute("select First_Name, Last_Name,Mob_No,Email_ID,DOB,Password from User_Data where ID=?",(no1,))
            j=k.fetchone()
            if j:
                full_name=j[0]+" "+j[1]
                q=ms.askyesno("Account Found",f"Accound No. {no1} is found\nIs this Account Name is {full_name}",parent=w15)
                if q:
                    acc_no.destroy()
                    acc_n01.destroy()
                    b1.destroy()
                    what=Label(w15,text="What Do you want to update\n1. Name\n2. Mobile Number\n3. Email ID\n4.Date of Birth\n5.Password",font=('arial',20),bg=w15['bg'],justify='left')
                    what.place(x=92, y=182)
                    enter=Entry(w15,font=("arial",20),)
                    enter.place(x=101, y=398)
                    def upp(no12):
                        vall=enter.get()
                        if vall=='1' or vall=="Name" or vall=="name":
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            N1=Label(w15,text="First Name:",font=("arial",30),bg=w15['bg'])
                            N1.place(x=78,y=179)
                            N2 = Label(w15, text="Last Name:", font=("arial", 30), bg=w15['bg'])
                            N2.place(x=78, y=301)
                            N1e=Entry(w15,font=("arial",20))
                            N1e.place(x=351,y=189)
                            N2e=Entry(w15,font=("arial",20))
                            N2e.place(x=351,y=310)
                            def naming(IDs):
                                first=N1e.get()
                                last=N2e.get()
                                if first=='':
                                    ms.showerror("Error","First Name cannot be empty",parent=w15)
                                elif last=='':
                                    ms.showerror("Error","Last name cannot be empty",parent=w15)
                                else:
                                    k.execute("update User_Data set First_Name=?,Last_Name=? where ID=?",(first,last,IDs))
                                    d.commit()
                                    ms.showinfo("Success","Name is updated",parent=w15)
                                    w15.destroy()
                            global sunn
                            sunn=ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110,60)))
                            subb=Button(w15,image=sunn,command=lambda : naming(no12),bg=w15['bg'],bd=0,activebackground=w15['bg'])
                            subb.place(x=380,y=401)
                        elif vall=='2' or vall=='Mobile Number' or vall=='mobile number':
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            MoN = Label(w15, text="Enter New Mobile Number:", font=("arial", 30), bg=w15['bg'])
                            MoN.place(x=78, y=179)
                            N1e = Entry(w15, font=("arial", 20))
                            N1e.place(x=85, y=247)
                            def new_mob(NO1):
                                mob_no=N1e.get()
                                if mob_no=='':
                                    ms.showerror("Error","Mobile number cannot be empty",parent=w15)
                                elif len(mob_no)>10:
                                    ms.showerror("Error","Mobile number should be 10 digit",parent=w15)
                                else:
                                    k.execute("update User_Data set Mob_No=? where ID=?",(mob_no, NO1))
                                    d.commit()
                                    ms.showinfo("Success", "Mobile Number is updated", parent=w15)
                                    w15.destroy()
                            global sunn1
                            sunn1 = ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110, 60)))
                            subb = Button(w15, image=sunn1,command=lambda :new_mob(no12),bg=w15['bg'], bd=0, activebackground=w15['bg'])
                            subb.place(x=461, y=247)
                        elif vall=='3' or vall=='Email ID' or vall=='email id':
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            Emaili = Label(w15, text="Enter New Email Address:", font=("arial", 30), bg=w15['bg'])
                            Emaili.place(x=78, y=179)
                            N1ei = Entry(w15, font=("arial", 20))
                            N1ei.place(x=85, y=247)
                            def new_email(i21):
                                new_mail=N1ei.get()
                                if new_mail=='':
                                    ms.showerror("Error","Email cannot be empty")
                                elif not re.search(r'^\w+@\w+\.[a-z]{2,3}$',new_mail):
                                    ms.showerror("Error",'It should follow email format')
                                else:
                                    k.execute("update User_Data set Email_ID=? where ID=?", (new_mail, i21))
                                    d.commit()
                                    ms.showinfo("Success", "Email is updated is updated", parent=w15)
                                    w15.destroy()
                            global subb23
                            sunn23 = ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110, 60)))
                            sett = Button(w15, image=sunn23, command=lambda: new_email(no12), bg=w15['bg'], bd=0,activebackground=w15['bg'])
                            sett.image=sunn23
                            sett.place(x=461, y=247)
                        elif vall=='4' or vall=='Date of Birth' or vall=='date of birth':
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            dob = Label(w15, text="Enter New Date of Birth:", font=("arial", 30), bg=w15['bg'])
                            dob.place(x=78, y=179)
                            dob1 = Entry(w15, font=("arial", 20))
                            dob1.place(x=85, y=247)
                            def new_dob(i21):
                                new_dob1=dob1.get()
                                if not re.search(r'^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(19\d\d|200[0-4])$',new_dob1) or new_dob1=='':
                                    ms.showerror("Error","Email cannot be empty or invalid")
                                else:
                                    k.execute("update User_Data set DOB=? where ID=?", (new_dob1, i21))
                                    d.commit()
                                    ms.showinfo("Success", "Date of birth is updated is updated", parent=w15)
                                    w15.destroy()
                            global sunn3
                            sunn3 = ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110, 60)))
                            subb = Button(w15, image=sunn3, command=lambda: new_dob(no12), bg=w15['bg'], bd=0,
                                              activebackground=w15['bg'])
                            subb.place(x=461, y=247)
                        elif vall=='5' or vall=='Password' or vall=='password':
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            pass1 = Label(w15, text="Enter New Password:", font=("arial", 30), bg=w15['bg'])
                            pass1.place(x=78, y=179)
                            pass2 = Entry(w15, font=("arial", 20))
                            pass2.place(x=85, y=247)
                            def new_pass(i21):
                                new_pass3=pass2.get()
                                if new_pass3=='':
                                    ms.showerror("Error","Password cannot be empty")
                                else:
                                    k.execute("update User_Data set Password=? where ID=?", (new_pass3, i21))
                                    d.commit()
                                    ms.showinfo("Success", "Password is updated is updated", parent=w15)
                                    w15.destroy()
                            global sunn4
                            sunn4 = ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110, 60)))
                            subb = Button(w15, image=sunn4, command=lambda: new_pass(no12), bg=w15['bg'], bd=0,
                                              activebackground=w15['bg'])
                            subb.place(x=461, y=247)
                    global subm
                    subm=ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110,60)))
                    sub=Button(w15,image=subm,command=lambda : upp(no1),bg=w15['bg'],bd=0,activebackground=w15['bg'])
                    sub.image=subm
                    sub.place(x=474,y=386)
                else:
                    pass
            else:
                ms.showerror("Error",'Account not found')
    global impo
    impo=ImageTk.PhotoImage(Image.open("find-user.png").resize((110,110)))
    b1=Button(w15,image=impo,command=find,bg=w15['bg'],bd=0,activebackground=w15['bg'])
    b1.place(x=328,y=275)
    w15.mainloop()
def del_acc():
    w16 = Toplevel()
    w16.geometry("800x400")
    w16.title("Delete Account")
    w16.resizable(False, False)
    w16.attributes("-topmost", True)
    w16.config(bg="#e6f0ff")
    l1 = Label(w16, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w16, text="Delete Account", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',
               fg="#4169E1")
    l2=Label(w16,text="Enter account number:",font=("arial",20),bg=w16['bg'])
    l2.place(x=64,y=184)
    l3=Entry(w16,font=("arial",20))
    l3.place(x=377,y=184)
    def dellacc():
        acc_no=l3.get()
        if acc_no=='':
            ms.showerror("Error","Account Number is wrong",parent=w16)
        else:
            k.execute("delete from User_Data where ID=?",(acc_no,))
            d.commit()
            ms.showinfo("Success",f"Account {acc_no} is deleted",parent=w16)
            w16.destroy()
    global dell
    dell = ImageTk.PhotoImage(Image.open("delete.png").resize((110,100)))
    dll1=Button(w16,image=dell,command=dellacc,bg=w16['bg'],bd=0,activebackground=w16['bg'])
    dll1.place(x=328,y=250)
    l4.pack()
    w16.mainloop()
def search_acc():
    w17 = Toplevel()
    w17.geometry("800x700")
    w17.title("Search Account")
    w17.resizable(False, False)
    w17.attributes("-topmost", True)
    w17.config(bg="#e6f0ff")
    l1 = Label(w17, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w17, text="Search Account", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
    l4.pack()
    l2 = Label(w17, text="Enter account number:", font=("arial", 20), bg=w17['bg'])
    l2.place(x=64, y=184)
    l3 = Entry(w17, font=("arial", 20))
    l3.place(x=377, y=184)
    def acc1():
        user_id=l3.get()
        if user_id=='':
            ms.showerror("Error","Account Number cannot be empty",parent=w17)
        else:
            k.execute("select * from User_data where ID=?",(user_id,))
            l=k.fetchone()
            if l:
                ms.showinfo("Success",f'Account No.{user_id} is found',parent=w17)
                l2.destroy()
                l4.destroy()
                l3.destroy()
                dll14.destroy()
                l5 = Label(w17, text="Account Detail", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
                l5.pack()
                stt=["Name:","Mobile Number:","Email ID:","Date of Birth:","Password:","Account No.:","Amount:","Account Type:"]
                tr=144
                for j in range(len(stt)):
                    info = Label(w17, text=f"{stt[j]}",font=("arial",20),bg=w17['bg'],justify='left')
                    info.place(x=52, y=tr)
                    tr+=56
                full_Name=l[0]+ ' '+l[1]
                data=Label(w17,text=f'{full_Name}',font=("arial",20),bg=w17['bg'],justify='left')
                data.place(x=408,y=144)
                dis=200
                for i in range(2, len(l)):
                    data1=Label(w17,text=f'{l[i]}',font=("arial",20),bg=w17['bg'],justify='left')
                    data1.place(x=408,y=dis)
                    dis+=56
    global dell4
    dell4 = ImageTk.PhotoImage(Image.open("find-user.png").resize((110, 100)))
    dll14 = Button(w17, image=dell4,command=acc1,  bg=w17['bg'], bd=0, activebackground=w17['bg'])
    dll14.place(x=328, y=250)
    l4.pack()

    w17.mainloop()
def show_all_accounts():
    import tkinter as tk
    w18 = Toplevel()
    w18.title("All Accounts")
    w18.geometry("1500x500")
    w18.config(bg="#e6f0ff")
    w18.resizable(False, False)
    l1 = Label(w18, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w18, text="All Account", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
    l4.pack()
    canvas = Canvas(w18, bg="#e6f0ff")
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    v_scroll = Scrollbar(w18, orient=tk.VERTICAL, command=canvas.yview)
    v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    canvas.configure(yscrollcommand=v_scroll.set)
    table_frame = tk.Frame(canvas, bg="#e6f0ff")
    window = canvas.create_window((0, 0), window=table_frame, anchor='nw')
    k.execute("SELECT * FROM User_Data")
    rows = k.fetchall()
    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))
        canvas.itemconfig(window, width=max(canvas.winfo_width(), table_frame.winfo_reqwidth()))
    table_frame.bind("<Configure>", on_frame_configure)
    headers = ["First Name", "Last Name", "Mob No", "Email ID", "DOB", "Password", "Account Number", "Balance", "Acc Type"]
    for i, header in enumerate(headers):
        Label(table_frame, text=header, font=("Arial", 12, 'bold'), bg='lightgrey',padx=5, pady=5, borderwidth=1, relief="solid", width=15).grid(row=0, column=i)
    for row_num, row in enumerate(rows):
        for col_num, value in enumerate(row):
            Label(table_frame, text=value, font=("Arial", 11), bg='white',padx=5, pady=5, borderwidth=1, relief="solid", width=15).grid(row=row_num + 1, column=col_num)
    w18.mainloop()
def loan(IDe):
    w19=Toplevel()
    w19.title("Loan Initiate")
    w19.geometry("900x650")
    w19.config(bg="#e6f0ff")
    w19.resizable(False, False)
    l1 = Label(w19, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w19, text="Loan Initiate", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
    l4.pack()
    l2=Label(w19,text="Account Number",font=("Arial",20),bg=w19['bg'])
    l2.place(x=64,y=163)
    l3=Label(w19,text="Name",font=("arial",20),bg=w19['bg'])
    l3.place(x=64,y=233)
    l5=Label(w19,text="Amount",font=("arial",20),bg=w19['bg'])
    l5.place(x=64,y=313)
    l6=Label(w19,text="Return Date",font=("arial",20),bg=w19['bg'])
    l6.place(x=64,y=393)
    b1=Entry(w19,font=("arial",20))
    b1.place(x=429,y=163)
    b2=Entry(w19,font=("arial",20))
    b2.place(x=429,y= 233)
    b3=Entry(w19,font=("arial",20))
    b3.place(x=429,y=313)
    b4=Entry(w19,font=("arial",20))
    b4.place(x=429,y=393)
    def loans():
        ac_no=b1.get()
        name=b2.get()
        amu=b3.get()
        date=b4.get()
        if ac_no=='':
            ms.showerror("Error","Account number cannot be empty",parent=w19)
        elif name =="":
            ms.showerror("Error","Name cannot be empty",parent=w19)
        elif amu=="":
            ms.showerror("Error","Amount cannot be empty",parent=w19)
        elif not re.search(r"^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[0-2])[- /.](19|20)\d\d$",date) or date=='':
            ms.showerror("Error","Date cannot be empty or invalid",parent=w19)
        else:
            ac_no1=int(ac_no)
            amu1=int(amu)
            k.execute("select First_Name,Last_Name,ID from User_Data where ID=?",(ac_no1,))
            ad=k.fetchone()
            full_name=ad[0]+' '+ad[1]
            if not ad or full_name!=name:
                ms.showerror("Error","Account not found",parent=w19)
            else:
                k.execute("insert into Loan (Name,Amount,Return_Date,Loan_By,user_ID) values (?,?,?,?,?)",(name,amu1,date,IDe,ac_no1))
                d.commit()
                if k.rowcount>0:
                    k.execute("select Balance from User_Data where ID=?",(ac_no1,))
                    bal=k.fetchone()
                    new_bal=bal[0]+amu1
                    k.execute("update User_Data set Balance=? where ID=?",(new_bal,ac_no1))
                    d.commit()
                    ms.showinfo("Success", f"Load deposited to Account Number: {ac_no1} Successfully", parent=w19)
                    w19.destroy()
                else:
                    ms.showerror("Error",f"Loan Amount not added to Acount Number: {ac_no1}",parent=w19)
    global lo_sub
    lo_sub=ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110,60)))
    b11=Button(w19,image=lo_sub,command=loans,bg=w19['bg'],bd=0,activebackground=w19['bg'])
    b11.image=lo_sub
    b11.place(x=400,y=483)
    w19.mainloop()
def adminwork(a_ID,a_name):
    global w20
    try:
        w7.destroy()
    except:
        pass
    w20 = Tk()
    w20.title('admin logins')
    w20.geometry('1000x1000')
    w20.config(bg='#e6f0ff')
    w20.attributes('-fullscreen', True)
    w20.bind_all("<Escape>", lambda e: w20.attributes('-fullscreen', False))
    l2 = Label(w20, text='Capita bank', font=('arial', 40, 'bold', 'underline'), bg='#e6f0ff', fg='navy')
    l2.pack()
    l3=Label(w20,text='Admin Panel',font=('arial', 30, 'bold'),bg='#e6f0ff')
    l3.pack()
    l4=Label(w20,text=f'Welcome {a_name}\nID: {a_ID}',font=('arial', 30, 'bold'),bg='#e6f0ff', fg='navy')
    l4.pack()
    l5=Label(w20,text='Add New Employee                               Modify Employee                              Delete Employee                                view all Employee',font=('arial', 15, 'bold'),bg='#e6f0ff', fg='navy')
    l5.place(x=150,y=450)
    img1 = Image.open('new employee in admin.png')
    img1 = img1.resize((150, 150))
    photo1 = ImageTk.PhotoImage(image=img1)
    b1 = Button(w20, image=photo1,command=add_emp, bd=0, bg=w20['bg'], fg='black',activebackground=w20['bg'], padx=20)
    b1.place(x=170, y=300)
    b1.image = photo1
    img2 = Image.open('modify employee detail.png')
    img2 = img2.resize((150, 150))
    photo2 = ImageTk.PhotoImage(image=img2)
    b2 = Button(w20, image=photo2,command=modify_emp_acc, bd=0, bg=w20['bg'], fg='black', activebackground=w20['bg'], padx=20)
    b2.place(x=520, y=300)
    b2.image = photo2
    img3 = Image.open('delete employee.png')
    img3 = img3.resize((150, 150))
    photo3 = ImageTk.PhotoImage(image=img3)
    b3 = Button(w20, image=photo3,command=del_emp_acc, bd=0, bg=w20['bg'], fg='black', activebackground=w20['bg'], padx=20)
    b3.place(x=870, y=300)
    b3.image = photo3
    l6 = Label(w20, text='View all Customers                                      Admin Profile                                               Logout', font=('arial', 15, 'bold'), bg='#e6f0ff', fg='navy')
    l6.place(x=300, y=700)
    img4 = Image.open('view all employee.png')
    img4 = img4.resize((150, 150))
    photo4 = ImageTk.PhotoImage(image=img4)
    b4 = Button(w20, image=photo4,command=show_all_employee, bd=0, bg=w20['bg'], fg='black', activebackground=w20['bg'], padx=20)
    b4.place(x=1210, y=300)
    img5 = Image.open('all customers account.png')
    img5 = img5.resize((150, 150))
    photo5 = ImageTk.PhotoImage(image=img5)
    b5 = Button(w20, image=photo5,command=show_all_accounts, bd=0, bg=w20['bg'], fg='black', activebackground=w20['bg'], padx=20)
    b5.place(x=320, y=550)
    b5.image = photo5
    img6 = Image.open('admin-panel.png')
    img6 = img6.resize((150, 150))
    photo6 = ImageTk.PhotoImage(image=img6)
    b6 = Button(w20, image=photo6,command=lambda : show_admin_profile(a_ID),bd=0, bg=w20['bg'], fg='black', activebackground=w20['bg'], padx=20)
    b6.place(x=700, y=550)
    b6.image = photo6
    def logout():
        a=ms.askyesno("Logout","Do you really wanna logout")
        if a:
            ms.showinfo("Logout Successfull","Thanks you for your time")
            w20.destroy()
        else:
            ms.showinfo("Cancelled","Logout Cancelled")
    img7 = Image.open('logout.png')
    img7 = img7.resize((150, 150))
    photo7 = ImageTk.PhotoImage(image=img7)
    b7 = Button(w20, image=photo7, bd=0, bg=w20['bg'], command=logout, font=('arial', 20, 'bold'), fg='black',
                activebackground=w20['bg'])
    b7.place(x=1080, y=550)
    w20.mainloop()
def add_emp():
    w21=Toplevel()
    w21.geometry("800x700")
    w21.title("Add New Employee")
    w21.resizable(False,False)
    w21.attributes("-topmost",True)
    w21.config(bg="#e6f0ff")
    l1 = Label(w21, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w21, text="Add New Employee", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg="#4169E1")
    l4.pack()
    l5=Label(w21,text="Name:",font=("Arial",20),bg=w21['bg'],bd=0,activebackground=w21['bg'])
    l5.place(x=55,y=165)
    l7=Label(w21,text="Mobile Number:",font=("Arial",20),bg=w21['bg'],bd=0,activebackground=w21['bg'])
    l7.place(x=55,y=218)
    l8=Label(w21,text="Email ID:",font=("Arial",20),bg=w21['bg'],bd=0,activebackground=w21['bg'])
    l8.place(x=55,y=271)
    l9=Label(w21,text="Date Of Birth:",font=("Arial",20),bg=w21['bg'],bd=0,activebackground=w21['bg'])
    l9.place(x=55,y=324)
    l10=Label(w21,text="Password:",font=("Arial",20),bg=w21['bg'],bd=0,activebackground=w21['bg'])
    l10.place(x=55,y=377)
    l12 = Label(w21, text="Password Again:", font=("Arial", 20), bg=w21['bg'], bd=0, activebackground=w21['bg'])
    l12.place(x=55,y=430)
    FN=Entry(w21,font=("arial",20))
    FN.place(x=430,y=165)
    MN=Entry(w21,font=("arial",20))
    MN.place(x=430,y=218)
    EI=Entry(w21,font=("arial",20))
    EI.place(x=430,y=271)
    DOB=Entry(w21,font=("arial",20))
    DOB.place(x=430,y=324)
    P1=Entry(w21,font=("arial",20))
    P1.place(x=430,y=377)
    P2=Entry(w21,font=("arial",20))
    P2.place(x=430,y=430)
    def valid():
        First_name=FN.get()
        Mobile=MN.get()
        Email=EI.get()
        DateofBirth=DOB.get()
        Password1=P1.get()
        Password2=P2.get()
        if First_name=='':
            ms.showerror("Error","First Name cannot be empty",parent=w21)
        elif not re.search(r'^\w+@\w+\.[a-z]{2,3}$',Email) or Email =='':
            ms.showerror("Error",'Inavlid type or empty email',parent=w21)
        elif not re.search(r'^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(19\d\d|200[0-4])$',DateofBirth) or DateofBirth=='':
            ms.showerror("Error",'Date of Birth Cannot be Empty or invalid',parent=w21)
        elif Password1==''or Password2=='':
            ms.showerror('Error','Password cannot be empty',parent=w21)
        elif Password1 != Password2:
            ms.showerror("Error","Passwords are not same",parent=w21)
        else:
            Mobile1=int(Mobile)
            Password3=int(Password2)
            k.execute("insert into employee (Name,Email_ID,Mobile_No,Password,DOB) values (?,?,?,?,?)",(First_name,Email,Mobile1,Password3,DateofBirth))
            d.commit()
            k.execute("select ID from employee where Email_ID=? and Password=?",(Email,Password2))
            g=k.fetchone()
            if g:
                ms.showinfo("Success",f'Employee successfully added with Employee ID {g[0]}',parent=w21)
            else:
                ms.showerror("Error","Employee ID is not created\nPlease try after some time",parent=w21)
    global img
    img=ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110,60)))
    b1=Button(w21,image=img,command= valid,bg=w21['bg'],bd=0,activebackground=w21['bg'])
    b1.image=img
    b1.place(x=299,y=594)
    w21.mainloop()
def modify_emp_acc():
    w22 = Toplevel()
    w22.geometry("800x700")
    w22.title("Modify Employee")
    w22.resizable(False, False)
    w22.attributes("-topmost", True)
    w22.config(bg="#e6f0ff")
    l1 = Label(w22, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w22, text="Modify Employee Details", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',fg="#4169E1")
    l4.pack()
    acc_no=Label(w22,text="Enter Employee ID:",font=('arial',20),bg=w22['bg'])
    acc_no.place(x=59,y=192)
    acc_n01=Entry(w22,font=('arial',20))
    acc_n01.place(x=382,y=192)
    def find():
        no=acc_n01.get()
        if no=='':
            ms.showerror("Error","Employee ID is empty",parent=w22)
        else:
            no1=int(no)
            k.execute("select Name,Email_ID,Mobile_No,Password,DOB from employee where ID=?",(no1,))
            j=k.fetchone()
            if j:
                full_name=j[0]
                q=ms.askyesno("Employee ID Found",f"Employee ID {no1} is found\nIs this Account Name is {full_name}",parent=w22)
                if q:
                    acc_no.destroy()
                    acc_n01.destroy()
                    b1.destroy()
                    what=Label(w22,text="What Do you want to update\n1. Name\n2. Mobile Number\n3. Email ID\n4.Date of Birth\n5.Password",font=('arial',20),bg=w22['bg'],justify='left')
                    what.place(x=92, y=182)
                    enter=Entry(w22,font=("arial",20),)
                    enter.place(x=101, y=398)
                    def upp(no12):
                        vall=enter.get()
                        if vall=='1' or vall=="Name" or vall=="name":
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            N1=Label(w22,text="Enter New Name:",font=("arial",30),bg=w22['bg'])
                            N1.place(x=78,y=179)
                            N1e=Entry(w22,font=("arial",20))
                            N1e.place(x=351,y=189)
                            def naming():
                                first=N1e.get()
                                if first=='':
                                    ms.showerror("Error","First Name cannot be empty",parent=w22)
                                else:
                                    k.execute("update employee set Name=? where ID=?",(first,no1))
                                    d.commit()
                                    if k.rowcount>0:
                                        ms.showinfo("Success", "Name is updated", parent=w22)
                                        w22.destroy()
                                    else:
                                        ms.showerror("Error","Name not updated",parent=w22)
                            global sunn
                            sunn=ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110,60)))
                            subb=Button(w22,image=sunn,command=naming,bg=w22['bg'],bd=0,activebackground=w22['bg'])
                            subb.place(x=380,y=401)
                        elif vall=='2' or vall=='Mobile Number' or vall=='mobile number':
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            MoN = Label(w22, text="Enter New Mobile Number:", font=("arial", 30), bg=w22['bg'])
                            MoN.place(x=78, y=179)
                            N1e = Entry(w22, font=("arial", 20))
                            N1e.place(x=85, y=247)
                            def new_mob(no1):
                                mob_no=N1e.get()
                                if mob_no=='':
                                    ms.showerror("Error","Mobile number cannot be empty",parent=w22)
                                elif len(mob_no)>10:
                                    ms.showerror("Error","Mobile number should be 10 digit",parent=w22)
                                else:
                                    k.execute("update employee set Mobile_No=? where ID=?",(mob_no, no1))
                                    d.commit()
                                    ms.showinfo("Success", "Mobile Number is updated", parent=w22)
                                    w22.destroy()
                            global sunn1
                            sunn1 = ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110, 60)))
                            subb = Button(w22, image=sunn1,command=lambda :new_mob(no1),bg=w22['bg'], bd=0, activebackground=w22['bg'])
                            subb.place(x=461, y=247)
                        elif vall=='3' or vall=='Email ID' or vall=='email id':
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            Emaili = Label(w22, text="Enter New Email Address:", font=("arial", 30), bg=w22['bg'])
                            Emaili.place(x=78, y=179)
                            N1ei = Entry(w22, font=("arial", 20))
                            N1ei.place(x=85, y=247)
                            def new_email(i21):
                                new_mail=N1ei.get()
                                if new_mail=='':
                                    ms.showerror("Error","Email cannot be empty",parent=w22)
                                elif not re.search(r'^\w+@\w+\.[a-z]{2,3}$',new_mail):
                                    ms.showerror("Error",'It should follow email format',parent=w22)
                                else:
                                    k.execute("update employee set Email_ID=? where ID=?", (new_mail, i21))
                                    d.commit()
                                    ms.showinfo("Success", "Email is updated is updated", parent=w22)
                                    w22.destroy()
                            global subb23
                            sunn23 = ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110, 60)))
                            sett = Button(w22, image=sunn23, command=lambda: new_email(no1), bg=w22['bg'], bd=0,activebackground=w22['bg'])
                            sett.image=sunn23
                            sett.place(x=461, y=247)
                        elif vall=='4' or vall=='Date of Birth' or vall=='date of birth':
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            dob = Label(w22, text="Enter New Date of Birth:", font=("arial", 30), bg=w22['bg'])
                            dob.place(x=78, y=179)
                            dob1 = Entry(w22, font=("arial", 20))
                            dob1.place(x=85, y=247)
                            def new_dob(i21):
                                new_dob1=dob1.get()
                                if not re.search(r'^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(19\d\d|200[0-4])$',new_dob1) or new_dob1=='':
                                    ms.showerror("Error","Email cannot be empty or invalid",parent=w22)
                                else:
                                    k.execute("update employee set DOB=? where ID=?", (new_dob1, i21))
                                    d.commit()
                                    ms.showinfo("Success", "Date of birth is updated is updated", parent=w22)
                                    w22.destroy()
                            global sunn3
                            sunn3 = ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110, 60)))
                            subb = Button(w22, image=sunn3, command=lambda: new_dob(no1), bg=w22['bg'], bd=0,
                                              activebackground=w22['bg'])
                            subb.place(x=461, y=247)
                        elif vall=='5' or vall=='Password' or vall=='password':
                            what.destroy()
                            enter.destroy()
                            sub.destroy()
                            pass1 = Label(w22, text="Enter New Password:", font=("arial", 30), bg=w22['bg'])
                            pass1.place(x=78, y=179)
                            pass2 = Entry(w22, font=("arial", 20))
                            pass2.place(x=85, y=247)
                            def new_pass(i21):
                                new_pass3=pass2.get()
                                if new_pass3=='':
                                    ms.showerror("Error","Password cannot be empty",parent=w22)
                                else:
                                    k.execute("update employee set Password=? where ID=?", (new_pass3, i21))
                                    d.commit()
                                    ms.showinfo("Success", "Password is updated is updated", parent=w22)
                                    w22.destroy()
                            global sunn4
                            sunn4 = ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110, 60)))
                            subb = Button(w22, image=sunn4, command=lambda: new_pass(no1), bg=w22['bg'], bd=0,
                                              activebackground=w22['bg'])
                            subb.place(x=461, y=247)
                    global subm
                    subm=ImageTk.PhotoImage(Image.open("submit-button-png-18021.png").resize((110,60)))
                    sub=Button(w22,image=subm,command=lambda : upp(no1),bg=w22['bg'],bd=0,activebackground=w22['bg'])
                    sub.image=subm
                    sub.place(x=474,y=386)
                else:
                    pass
            else:
                ms.showerror("Error",'Employee not found')
    global impo
    impo=ImageTk.PhotoImage(Image.open("find-user.png").resize((110,110)))
    b1=Button(w22,image=impo,command=find,bg=w22['bg'],bd=0,activebackground=w22['bg'])
    b1.place(x=328,y=275)
    w22.mainloop()
def del_emp_acc():
    w23 = Toplevel()
    w23.geometry("800x400")
    w23.title("Delete Account")
    w23.resizable(False, False)
    w23.attributes("-topmost", True)
    w23.config(bg="#e6f0ff")
    l1 = Label(w23, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w23, text="Delete Account", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',
               fg="#4169E1")
    l2=Label(w23, text="Enter Employee ID:", font=("arial", 20), bg=w23['bg'])
    l2.place(x=64,y=184)
    l3=Entry(w23, font=("arial", 20))
    l3.place(x=377,y=184)
    def dellacc():
        acc_no=l3.get()
        if acc_no=='':
            ms.showerror("Error","Account Number is wrong", parent=w23)
        else:
            k.execute("delete from employee where ID=?",(acc_no,))
            d.commit()
            ms.showinfo("Success",f"Employee ID {acc_no} is deleted", parent=w23)
            w23.destroy()
    global dell
    dell = ImageTk.PhotoImage(Image.open("delete.png").resize((110,100)))
    dll1=Button(w23, image=dell, command=dellacc, bg=w23['bg'], bd=0, activebackground=w23['bg'])
    dll1.place(x=328,y=250)
    l4.pack()
    w23.mainloop()
def show_all_employee():
    import tkinter as tk
    from tkinter import Toplevel, Canvas, Scrollbar, Frame, Label
    w24 = Tk()
    w24.geometry("1400x700")
    w24.title("All Employees")
    w24.resizable(False, False)
    w24.attributes("-topmost", True)
    w24.config(bg="#e6f0ff")
    l1 = Label(w24, text="Capita Bank", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff', fg='#003366')
    l1.pack()
    l4 = Label(w24, text="All Employees", font=("times new roman", 30, 'bold', 'underline'), bg='#e6f0ff',
               fg="#4169E1")
    l4.pack()
    canvas =Canvas(w24,bg="#e6f0ff")
    canvas.pack(side=tk.LEFT,fill=tk.BOTH,expand=True)
    V_scroll=Scrollbar(w24,orient=tk.VERTICAL,command=canvas.yview)
    V_scroll.pack(side=tk.RIGHT,fill=tk.Y)
    canvas.config(yscrollcommand=V_scroll.set)
    frame=Frame(canvas,bg='#e6f0ff')
    canvas.create_window((0,0),window=frame,anchor='nw')
    def conn(event):
        canvas.config(scrollregion=canvas.bbox("all"))
        frame.bind("<Configure>",conn)
    k.execute("select ID,Name,Email_ID,Mobile_No,Password,DOB from employee")
    all_data=list(k.fetchall())
    yy=200
    if all_data:
        lenn=len(all_data)
        for i in range(0,lenn):
            xx = 0
            temp=all_data[i]
            for j in range(len(temp)):
                show = Label(w24, text=f'{temp[j]}', font=("arial", 20), bg=w24['bg'],justify='left')
                if j==3:
                    xx += 380
                elif j==2:
                    xx+=180
                elif j==4:
                    xx+=200
                elif j==5:
                    xx+=200
                else:
                    xx += 100
                show.place(x=xx, y=yy)
            yy += 50
    dell22=Label(w24,text="ID          Name                        Email ID                    Mobile No.       Password        Date Of Birth",font=("arial",20,'bold'),bg=w24['bg'])
    dell22.place(x=117,y=150)
    w24.mainloop()
def show_admin_profile(admin_id):
    w25 = Toplevel()
    w25.title("Admin Profile")
    w25.geometry("650x400")
    w25.config(bg="#e6f0ff")
    w25.resizable(False, False)
    k.execute("SELECT ID,FULL_name,DOB, mobile_no, Email_id, Password FROM Admin WHERE ID=?", (admin_id,))
    data = k.fetchone()
    if not data:
        ms.showerror("Error", "Admin ID not found")
        return
    Label(w25, text="Admin Profile", font=("Arial", 25, "bold", "underline"), bg=w25["bg"], fg="#003366").pack(pady=20)
    labels = ["ID","Name","Date of Birth", "Mobile Number","Email ID", "Password"]
    for i, field in enumerate(data):
        Label(w25, text=f"{labels[i]}: {field}", font=("Arial", 16), bg=w25["bg"], anchor='w').pack(pady=5, anchor='w', padx=30)
    img=ImageTk.PhotoImage(Image.open("admin_is_me.jpg").resize((160,200)))
    img1=Label(w25,image=img)
    img1.place(x=430,y=100)
    w25.mainloop()
Start()